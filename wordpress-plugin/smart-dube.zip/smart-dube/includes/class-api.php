<?php
/**
 * Smart Dube REST API Endpoints Handler
 *
 * @package SmartDube
 */

if (!defined('ABSPATH')) {
    exit;
}

class Smart_Dube_API {

    public static function register_routes() {
        $namespace = 'smart-dube/v1';

        // 1. Auth routes
        register_rest_route($namespace, '/auth/login', [
            'methods'  => 'POST',
            'callback' => [__CLASS__, 'login_user'],
            'permission_callback' => '__return_true'
        ]);

        register_rest_route($namespace, '/auth/register', [
            'methods'  => 'POST',
            'callback' => [__CLASS__, 'register_user'],
            'permission_callback' => '__return_true'
        ]);

        register_rest_route($namespace, '/auth/me', [
            'methods'  => 'GET',
            'callback' => [__CLASS__, 'get_me'],
            'permission_callback' => '__return_true'
        ]);

        register_rest_route($namespace, '/auth/forgot-password', [
            'methods'  => 'POST',
            'callback' => [__CLASS__, 'forgot_password'],
            'permission_callback' => '__return_true'
        ]);

        register_rest_route($namespace, '/auth/reset-password', [
            'methods'  => 'POST',
            'callback' => [__CLASS__, 'reset_password'],
            'permission_callback' => '__return_true'
        ]);

        // 2. Merchant routes
        register_rest_route($namespace, '/merchant/profile', [
            'methods'  => 'GET',
            'callback' => [__CLASS__, 'get_merchant_profile'],
            'permission_callback' => '__return_true'
        ]);

        register_rest_route($namespace, '/merchant/customers', [
            'methods'  => ['GET', 'POST'],
            'callback' => [__CLASS__, 'handle_merchant_customers'],
            'permission_callback' => '__return_true'
        ]);

        register_rest_route($namespace, '/merchant/transactions', [
            'methods'  => ['GET', 'POST'],
            'callback' => [__CLASS__, 'handle_merchant_transactions'],
            'permission_callback' => '__return_true'
        ]);

        register_rest_route($namespace, '/merchant/approve-repayment', [
            'methods'  => 'POST',
            'callback' => [__CLASS__, 'approve_repayment'],
            'permission_callback' => '__return_true'
        ]);

        register_rest_route($namespace, '/merchant/sms-reminder', [
            'methods'  => 'POST',
            'callback' => [__CLASS__, 'send_merchant_sms'],
            'permission_callback' => '__return_true'
        ]);

        // 3. Customer routes
        register_rest_route($namespace, '/customer/dashboard', [
            'methods'  => 'GET',
            'callback' => [__CLASS__, 'get_customer_dashboard'],
            'permission_callback' => '__return_true'
        ]);

        register_rest_route($namespace, '/customer/repay', [
            'methods'  => 'POST',
            'callback' => [__CLASS__, 'customer_repay'],
            'permission_callback' => '__return_true'
        ]);

        register_rest_route($namespace, '/customer/schedule', [
            'methods'  => ['GET', 'POST'],
            'callback' => [__CLASS__, 'handle_customer_schedule'],
            'permission_callback' => '__return_true'
        ]);

        register_rest_route($namespace, '/customer/schedule/apply', [
            'methods'  => 'POST',
            'callback' => [__CLASS__, 'apply_customer_schedule'],
            'permission_callback' => '__return_true'
        ]);

        // 4. Admin routes
        register_rest_route($namespace, '/admin/dashboard', [
            'methods'  => 'GET',
            'callback' => [__CLASS__, 'get_admin_dashboard'],
            'permission_callback' => '__return_true'
        ]);

        register_rest_route($namespace, '/admin/gateways', [
            'methods'  => 'GET',
            'callback' => [__CLASS__, 'get_admin_gateways'],
            'permission_callback' => '__return_true'
        ]);

        register_rest_route($namespace, '/admin/audit-logs', [
            'methods'  => 'GET',
            'callback' => [__CLASS__, 'get_admin_audit_logs'],
            'permission_callback' => '__return_true'
        ]);

        register_rest_route($namespace, '/admin/kyc/(?P<id>\d+)', [
            'methods'  => ['POST', 'PUT'],
            'callback' => [__CLASS__, 'update_merchant_kyc'],
            'permission_callback' => '__return_true'
        ]);

        register_rest_route($namespace, '/admin/webhook-test', [
            'methods'  => 'POST',
            'callback' => [__CLASS__, 'handle_webhook_test'],
            'permission_callback' => '__return_true'
        ]);
    }

    // Helper to decode JWT-like token or user authentication
    private static function get_authenticated_user($request) {
        global $wpdb;
        $auth_header = $request->get_header('authorization');
        if (empty($auth_header)) {
            return null;
        }

        $token = str_replace('Bearer ', '', $auth_header);
        $parts = explode('.', $token);
        if (count($parts) === 3) {
            $b64 = str_replace(['-', '_'], ['+', '/'], $parts[1]);
            $remainder = strlen($b64) % 4;
            if ($remainder) {
                $b64 .= str_repeat('=', 4 - $remainder);
            }
            $payload = json_decode(base64_decode($b64), true);
            if (!empty($payload['id'])) {
                $table_users = $wpdb->prefix . 'dube_users';
                return $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_users WHERE id = %d", $payload['id']), ARRAY_A);
            }
        }
        return null;
    }

    public static function normalize_phone($phone) {
        $clean = preg_replace('/[^0-9]/', '', trim((string)$phone));
        if (empty($clean)) return '';
        if (strpos($clean, '251') === 0) {
            return '+' . $clean;
        }
        if (strpos($clean, '0') === 0) {
            return '+251' . substr($clean, 1);
        }
        if (strlen($clean) === 9) {
            return '+251' . $clean;
        }
        return '+' . $clean;
    }

    // 1. Auth: Login
    public static function login_user($request) {
        global $wpdb;
        Smart_Dube_Database::maybe_init_tables();
        
        $params = $request->get_json_params();
        $raw_phone = trim($params['phone'] ?? '');
        $normalized_phone = self::normalize_phone($raw_phone);
        $clean_digits = preg_replace('/[^0-9]/', '', $raw_phone);
        $last_9 = strlen($clean_digits) >= 9 ? substr($clean_digits, -9) : $clean_digits;
        $password = trim($params['password'] ?? '');

        $table_users = $wpdb->prefix . 'dube_users';
        $user = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_users WHERE phone = %s OR phone = %s OR phone = %s OR phone = %s OR phone LIKE %s ORDER BY id DESC LIMIT 1",
            $raw_phone,
            $normalized_phone,
            '+251' . $last_9,
            '0' . $last_9,
            '%' . $wpdb->esc_like($last_9)
        ), ARRAY_A);

        $is_valid_pass = false;
        if ($user && !empty($user['password_hash'])) {
            $stored_hash = trim($user['password_hash']);
            if (password_verify($password, $stored_hash) ||
                password_verify(trim($password), $stored_hash) ||
                password_verify(stripslashes($password), $stored_hash) ||
                password_verify(urldecode($password), $stored_hash) ||
                password_verify(html_entity_decode($password), $stored_hash) ||
                wp_check_password($password, $stored_hash) ||
                wp_check_password(trim($password), $stored_hash) ||
                $stored_hash === $password ||
                $stored_hash === md5($password) ||
                $stored_hash === sha1($password)) {
                $is_valid_pass = true;
            }
        }

        if (!$user || !$is_valid_pass) {
            return new WP_REST_Response(['error' => 'Invalid phone number or password credentials.'], 401);
        }

        $merchant = null;
        if ($user['role'] === 'MERCHANT') {
            $table_merchants = $wpdb->prefix . 'dube_merchants';
            $merchant = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_merchants WHERE user_id = %d", $user['id']), ARRAY_A);
        }

        $customerProfile = null;
        if ($user['role'] === 'CUSTOMER') {
            $table_cp = $wpdb->prefix . 'dube_customer_profiles';
            $customerProfile = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_cp WHERE user_id = %d OR phone = %s OR phone LIKE %s", $user['id'], $user['phone'], '%' . $wpdb->esc_like($last_9)), ARRAY_A);
        }

        // Generate standard token
        $header = base64_encode(json_encode(['typ' => 'JWT', 'alg' => 'HS256']));
        $payload = base64_encode(json_encode([
            'id' => $user['id'],
            'fullName' => $user['full_name'],
            'phone' => $user['phone'],
            'role' => $user['role'],
            'merchantId' => $merchant ? $merchant['id'] : null,
            'customerId' => $customerProfile ? $customerProfile['id'] : null,
            'exp' => time() + (7 * 86400)
        ]));
        $token = "$header.$payload.wp_signature";

        return new WP_REST_Response([
            'message' => 'Login successful',
            'token' => $token,
            'user' => [
                'id' => $user['id'],
                'fullName' => $user['full_name'],
                'phone' => $user['phone'],
                'role' => $user['role'],
                'faydaId' => $user['fayda_id'],
                'photo_url' => $user['photo_url'],
                'photoUrl' => $user['photo_url'],
                'merchant' => $merchant,
                'customerProfile' => $customerProfile
            ]
        ], 200);
    }

    // 2. Auth: Register
    public static function register_user($request) {
        global $wpdb;
        Smart_Dube_Database::maybe_init_tables();
        
        $params = $request->get_json_params();
        $table_users = $wpdb->prefix . 'dube_users';

        $raw_phone = trim($params['phone'] ?? '');
        $clean_digits = preg_replace('/[^0-9]/', '', $raw_phone);
        $normalized_phone = self::normalize_phone($raw_phone);
        $last_9 = strlen($clean_digits) >= 9 ? substr($clean_digits, -9) : $clean_digits;

        $full_name = sanitize_text_field($params['fullName'] ?? '');
        $email = sanitize_email($params['email'] ?? '');
        $role = strtoupper(sanitize_text_field($params['role'] ?? 'CUSTOMER'));
        $password = trim($params['password'] ?? '');
        $fayda_id = sanitize_text_field($params['faydaId'] ?? '');
        $photo_url = sanitize_text_field($params['photoUrl'] ?? "https://api.dicebear.com/7.x/avataaars/svg?seed=" . urlencode($full_name));

        if (empty($raw_phone) || empty($password)) {
            return new WP_REST_Response(['error' => 'Phone and password are required.'], 400);
        }

        if (strlen($clean_digits) < 9 || (strpos($clean_digits, '251') === 0 && strlen($clean_digits) < 12)) {
            return new WP_REST_Response([
                'error' => 'Please provide a valid complete 9-digit Ethiopian phone number (e.g., +251911223344 or 0911223344).'
            ], 400);
        }

        $password_hash = password_hash($password, PASSWORD_BCRYPT);

        // Atomic Upsert into Users Table
        $wpdb->query($wpdb->prepare(
            "INSERT INTO $table_users (full_name, phone, email, role, password_hash, fayda_id, photo_url) 
             VALUES (%s, %s, %s, %s, %s, %s, %s) 
             ON DUPLICATE KEY UPDATE 
                full_name = VALUES(full_name), 
                password_hash = VALUES(password_hash), 
                role = VALUES(role), 
                email = VALUES(email), 
                fayda_id = VALUES(fayda_id), 
                photo_url = VALUES(photo_url)",
            $full_name,
            $normalized_phone,
            $email,
            $role,
            $password_hash,
            $fayda_id,
            $photo_url
        ));
        
        $user_id = $wpdb->insert_id;
        if (!$user_id) {
            $user_id = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM $table_users WHERE phone = %s OR phone = %s OR phone = %s OR phone LIKE %s ORDER BY id DESC LIMIT 1",
                $normalized_phone,
                $raw_phone,
                '+251' . $last_9,
                '%' . $wpdb->esc_like($last_9)
            ));
        }

        if (!$user_id) {
            $user_id = 1;
        }

        $merchant = null;
        if ($role === 'MERCHANT') {
            $table_merchants = $wpdb->prefix . 'dube_merchants';
            $exists_merchant = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_merchants WHERE user_id = %d", $user_id), ARRAY_A);
            if (!$exists_merchant) {
                $wpdb->insert($table_merchants, [
                    'user_id' => $user_id,
                    'store_name' => sanitize_text_field($params['storeName'] ?? "$full_name's Store"),
                    'business_license_no' => sanitize_text_field($params['businessLicenseNo'] ?? 'BL-PENDING'),
                    'address' => sanitize_text_field($params['address'] ?? 'Addis Ababa'),
                    'kyc_status' => 'PENDING'
                ]);
                $merchant = ['id' => $wpdb->insert_id, 'kycStatus' => 'PENDING'];
            } else {
                $merchant = $exists_merchant;
            }
        }

        $customerProfile = null;
        if ($role === 'CUSTOMER') {
            $table_cp = $wpdb->prefix . 'dube_customer_profiles';
            $customerProfile = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_cp WHERE user_id = %d OR phone = %s OR phone LIKE %s", $user_id, $normalized_phone, '%' . $wpdb->esc_like($last_9)), ARRAY_A);
        }

        // Generate standard token for instant auto-login
        $header = base64_encode(json_encode(['typ' => 'JWT', 'alg' => 'HS256']));
        $payload = base64_encode(json_encode([
            'id' => $user_id,
            'fullName' => $full_name,
            'phone' => $normalized_phone,
            'role' => $role,
            'merchantId' => $merchant ? $merchant['id'] : null,
            'customerId' => $customerProfile ? $customerProfile['id'] : null,
            'exp' => time() + (7 * 86400)
        ]));
        $token = "$header.$payload.wp_signature";

        return new WP_REST_Response([
            'message' => 'User registered successfully',
            'token' => $token,
            'user' => [
                'id' => $user_id,
                'fullName' => $full_name,
                'phone' => $normalized_phone,
                'role' => $role,
                'faydaId' => $fayda_id,
                'photo_url' => $photo_url,
                'photoUrl' => $photo_url,
                'merchant' => $merchant,
                'customerProfile' => $customerProfile
            ]
        ], 201);
    }

    // 3. Auth: getMe
    public static function get_me($request) {
        global $wpdb;
        $user = self::get_authenticated_user($request);
        if (!$user) {
            return new WP_REST_Response(['error' => 'User not found or unauthenticated'], 401);
        }

        $merchant = null;
        $customerProfile = null;
        if ($user['role'] === 'MERCHANT') {
            $table_merchants = $wpdb->prefix . 'dube_merchants';
            $merchant = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_merchants WHERE user_id = %d", $user['id']), ARRAY_A);
        } elseif ($user['role'] === 'CUSTOMER') {
            $table_cp = $wpdb->prefix . 'dube_customer_profiles';
            $customerProfile = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_cp WHERE user_id = %d OR phone = %s", $user['id'], $user['phone']), ARRAY_A);
        }

        return new WP_REST_Response([
            'user' => [
                'id' => $user['id'],
                'fullName' => $user['full_name'],
                'phone' => $user['phone'],
                'email' => $user['email'],
                'role' => $user['role'],
                'faydaId' => $user['fayda_id'],
                'photo_url' => $user['photo_url'],
                'photoUrl' => $user['photo_url'],
                'merchant' => $merchant,
                'customerProfile' => $customerProfile
            ]
        ], 200);
    }

    // 4. Merchant Dashboard Profile & Stats
    public static function get_merchant_profile($request) {
        global $wpdb;
        $user = self::get_authenticated_user($request);
        $table_merchants = $wpdb->prefix . 'dube_merchants';
        $merchant = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_merchants WHERE user_id = %d", $user ? $user['id'] : 2), ARRAY_A);

        return new WP_REST_Response(['merchant' => $merchant], 200);
    }

    // 5. Merchant Customers list & creation
    public static function handle_merchant_customers($request) {
        global $wpdb;
        $user = self::get_authenticated_user($request);
        $table_merchants = $wpdb->prefix . 'dube_merchants';
        $merchant = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_merchants WHERE user_id = %d", $user ? $user['id'] : 2), ARRAY_A);
        $merchant_id = $merchant ? $merchant['id'] : 1;

        $table_cp = $wpdb->prefix . 'dube_customer_profiles';

        if ($request->get_method() === 'POST') {
            $params = $request->get_json_params();
            $wpdb->insert($table_cp, [
                'merchant_id' => $merchant_id,
                'full_name' => sanitize_text_field($params['fullName'] ?? ''),
                'phone' => sanitize_text_field($params['phone'] ?? ''),
                'fayda_id' => sanitize_text_field($params['faydaId'] ?? ''),
                'credit_limit' => floatval($params['creditLimit'] ?? 5000),
                'current_balance' => 0.00,
                'status' => 'ACTIVE'
            ]);
            return new WP_REST_Response(['message' => 'Customer profile created', 'id' => $wpdb->insert_id], 201);
        }

        $customers = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_cp WHERE merchant_id = %d", $merchant_id), ARRAY_A);
        return new WP_REST_Response(['customers' => $customers], 200);
    }

    // 6. Merchant Transactions list & creation
    public static function handle_merchant_transactions($request) {
        global $wpdb;
        $user = self::get_authenticated_user($request);
        $table_merchants = $wpdb->prefix . 'dube_merchants';
        $merchant = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_merchants WHERE user_id = %d", $user ? $user['id'] : 2), ARRAY_A);
        $merchant_id = $merchant ? $merchant['id'] : 1;

        $table_tx = $wpdb->prefix . 'dube_credit_transactions';
        $table_cp = $wpdb->prefix . 'dube_customer_profiles';

        if ($request->get_method() === 'POST') {
            $params = $request->get_json_params();
            $customer_id = intval($params['customerId']);
            $total_amount = floatval($params['totalAmount']);
            $items_json = json_encode($params['items'] ?? []);

            $tx_ref = 'DUBE-' . strtoupper(wp_generate_password(6, false));
            $wpdb->insert($table_tx, [
                'transaction_ref' => $tx_ref,
                'customer_id' => $customer_id,
                'merchant_id' => $merchant_id,
                'items_json' => $items_json,
                'total_amount' => $total_amount,
                'due_date' => !empty($params['dueDate']) ? sanitize_text_field($params['dueDate']) : date('Y-m-d', strtotime('+14 days')),
                'status' => 'PENDING',
                'notes' => sanitize_text_field($params['notes'] ?? 'Dube Credit Sale')
            ]);

            // Update customer balance
            $wpdb->query($wpdb->prepare("UPDATE $table_cp SET current_balance = current_balance + %f WHERE id = %d", $total_amount, $customer_id));

            // Send SMS notification
            $customer = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_cp WHERE id = %d", $customer_id), ARRAY_A);
            if ($customer && !empty($customer['phone'])) {
                Smart_Dube_SMS::send_sms(
                    $customer['phone'],
                    "[Smart Dube] New credit sale of " . number_format($total_amount, 2) . " ETB at {$merchant['store_name']}. Total Balance: " . number_format($customer['current_balance'] + $total_amount, 2) . " ETB.",
                    $customer_id,
                    'CREDIT_ISSUED'
                );
            }

            return new WP_REST_Response([
                'message' => 'Credit transaction logged successfully',
                'transactionRef' => $tx_ref,
                'transaction' => [
                    'id' => $wpdb->insert_id,
                    'txRef' => $tx_ref,
                    'transaction_ref' => $tx_ref,
                    'total_amount' => $total_amount,
                    'status' => 'PENDING'
                ]
            ], 201);
        }

        $transactions = $wpdb->get_results($wpdb->prepare(
            "SELECT tx.*, cp.full_name as customer_name, cp.phone as customer_phone 
             FROM $table_tx tx 
             LEFT JOIN $table_cp cp ON tx.customer_id = cp.id 
             WHERE tx.merchant_id = %d 
             ORDER BY tx.id DESC", 
            $merchant_id
        ), ARRAY_A);

        if (!empty($transactions)) {
            foreach ($transactions as &$tx) {
                if (!empty($tx['items_json'])) {
                    $decoded = json_decode($tx['items_json'], true);
                    $tx['items'] = is_array($decoded) ? $decoded : [];
                } else {
                    $tx['items'] = [];
                }
                $tx['total_amount'] = floatval($tx['total_amount'] ?? 0);
            }
            unset($tx);
        } else {
            $transactions = [];
        }

        $table_rep = $wpdb->prefix . 'dube_repayments';

        // Auto-heal any older repayments where merchant_id was 0 or null
        $wpdb->query("UPDATE $table_rep r JOIN $table_cp cp ON r.customer_id = cp.id SET r.merchant_id = cp.merchant_id WHERE r.merchant_id = 0 OR r.merchant_id IS NULL");
        $wpdb->query("UPDATE $table_rep r JOIN $table_tx t ON r.transaction_id = t.id SET r.merchant_id = t.merchant_id WHERE r.merchant_id = 0 OR r.merchant_id IS NULL");

        $repayments = $wpdb->get_results($wpdb->prepare(
            "SELECT rep.*, cp.full_name as customer_name, cp.phone as customer_phone 
             FROM $table_rep rep 
             LEFT JOIN $table_cp cp ON rep.customer_id = cp.id 
             WHERE rep.merchant_id = %d OR rep.customer_id IN (SELECT id FROM $table_cp WHERE merchant_id = %d)
             ORDER BY rep.id DESC", 
            $merchant_id,
            $merchant_id
        ), ARRAY_A);

        if (!empty($repayments)) {
            foreach ($repayments as &$r) {
                $r['amount'] = floatval($r['amount'] ?? 0);
            }
            unset($r);
        } else {
            $repayments = [];
        }

        return new WP_REST_Response([
            'transactions' => $transactions,
            'repayments' => $repayments,
            'pendingReceipts' => array_values(array_filter($repayments, function($r) { return $r['status'] === 'PENDING'; }))
        ], 200);
    }

    // 7. Approve Repayment
    public static function approve_repayment($request) {
        global $wpdb;
        $params = $request->get_json_params();
        $repayment_id = intval($params['repaymentId'] ?? 0);
        $action = strtoupper(sanitize_text_field($params['action'] ?? 'APPROVE'));

        $table_rep = $wpdb->prefix . 'dube_repayments';
        $table_cp  = $wpdb->prefix . 'dube_customer_profiles';
        $table_tx  = $wpdb->prefix . 'dube_credit_transactions';

        $repayment = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_rep WHERE id = %d", $repayment_id), ARRAY_A);
        if ($repayment) {
            if ($action === 'REJECT') {
                $wpdb->update($table_rep, ['status' => 'REJECTED'], ['id' => $repayment_id]);
                return new WP_REST_Response(['message' => 'Payment receipt rejected successfully'], 200);
            }

            // Action is APPROVE:
            $wpdb->update($table_rep, ['status' => 'COMPLETED'], ['id' => $repayment_id]);

            // Deduct customer current balance
            $wpdb->query($wpdb->prepare("UPDATE $table_cp SET current_balance = GREATEST(0, current_balance - %f) WHERE id = %d", $repayment['amount'], $repayment['customer_id']));

            // Settle transaction if transaction_id exists
            if (!empty($repayment['transaction_id'])) {
                $tx_id = intval($repayment['transaction_id']);
                $total_paid = floatval($wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount), 0) FROM $table_rep WHERE transaction_id = %d AND status = 'COMPLETED'", $tx_id)));
                $tx_total = floatval($wpdb->get_var($wpdb->prepare("SELECT total_amount FROM $table_tx WHERE id = %d", $tx_id)));
                if ($total_paid >= $tx_total) {
                    $wpdb->update($table_tx, ['status' => 'SETTLED'], ['id' => $tx_id]);
                } else if ($total_paid > 0) {
                    $wpdb->update($table_tx, ['status' => 'PARTIALLY_PAID'], ['id' => $tx_id]);
                }
            } else {
                // If transaction_id was not set, find oldest pending transaction for customer & merchant
                $pending_tx = $wpdb->get_row($wpdb->prepare("SELECT id, total_amount FROM $table_tx WHERE customer_id = %d AND merchant_id = %d AND status IN ('PENDING', 'PARTIALLY_PAID') ORDER BY id ASC LIMIT 1", $repayment['customer_id'], $repayment['merchant_id']), ARRAY_A);
                if ($pending_tx) {
                    $wpdb->update($table_rep, ['transaction_id' => $pending_tx['id']], ['id' => $repayment_id]);
                    $wpdb->update($table_tx, ['status' => 'SETTLED'], ['id' => $pending_tx['id']]);
                }
            }
        }

        return new WP_REST_Response(['message' => 'Repayment approved successfully and customer debt balance updated'], 200);
    }

    // 8. Send SMS Reminder
    public static function send_merchant_sms($request) {
        $params = $request->get_json_params();
        $phone = sanitize_text_field($params['phone'] ?? '');
        $message = sanitize_textarea_field($params['message'] ?? '');
        $customer_id = intval($params['customerId'] ?? 0);

        $result = Smart_Dube_SMS::send_sms($phone, $message, $customer_id, 'REMINDER');
        return new WP_REST_Response(['message' => 'SMS reminder dispatched successfully', 'result' => $result], 200);
    }

    // 9. Customer Dashboard
    public static function get_customer_dashboard($request) {
        global $wpdb;
        $user = self::get_authenticated_user($request);
        $user_id = $user ? $user['id'] : 4;

        $table_cp = $wpdb->prefix . 'dube_customer_profiles';
        $table_merchants = $wpdb->prefix . 'dube_merchants';
        $table_tx = $wpdb->prefix . 'dube_credit_transactions';
        $table_rep = $wpdb->prefix . 'dube_repayments';

        $profiles = $wpdb->get_results($wpdb->prepare(
            "SELECT cp.*, m.store_name, m.address as store_address 
             FROM $table_cp cp 
             JOIN $table_merchants m ON cp.merchant_id = m.id 
             WHERE cp.user_id = %d OR cp.phone = %s",
            $user_id,
            $user ? $user['phone'] : ''
        ), ARRAY_A);

        $transactions = $wpdb->get_results($wpdb->prepare(
            "SELECT tx.*, m.store_name 
             FROM $table_tx tx 
             LEFT JOIN $table_merchants m ON tx.merchant_id = m.id 
             WHERE tx.customer_id IN (SELECT id FROM $table_cp WHERE user_id = %d OR phone = %s)
             ORDER BY tx.id DESC", 
            $user_id,
            $user ? $user['phone'] : ''
        ), ARRAY_A);

        if (!empty($transactions)) {
            foreach ($transactions as &$tx) {
                if (!empty($tx['items_json'])) {
                    $decoded = json_decode($tx['items_json'], true);
                    $tx['items'] = is_array($decoded) ? $decoded : [];
                } else {
                    $tx['items'] = [];
                }
                $tx['total_amount'] = floatval($tx['total_amount'] ?? 0);

                // Check for pending repayment
                $pending_rep = $wpdb->get_row($wpdb->prepare(
                    "SELECT id, repayment_ref, amount, payment_gateway, reference_code, created_at, receipt_url 
                     FROM $table_rep 
                     WHERE (transaction_id = %d OR reference_code = %s) AND status = 'PENDING' 
                     ORDER BY id DESC LIMIT 1", 
                    $tx['id'], 
                    $tx['transaction_ref']
                ), ARRAY_A);
                $tx['has_pending_repayment'] = !empty($pending_rep);
                $tx['pending_repayment'] = $pending_rep ?: null;
            }
            unset($tx);
        } else {
            $transactions = [];
        }

        $repayments = $wpdb->get_results($wpdb->prepare(
            "SELECT rep.*, COALESCE(m.store_name, cp_m.store_name, 'Merchant Store') as store_name 
             FROM $table_rep rep 
             LEFT JOIN $table_merchants m ON rep.merchant_id = m.id 
             LEFT JOIN $table_cp cp ON rep.customer_id = cp.id 
             LEFT JOIN $table_merchants cp_m ON cp.merchant_id = cp_m.id 
             WHERE rep.customer_id IN (SELECT id FROM $table_cp WHERE user_id = %d OR phone = %s)
             ORDER BY rep.id DESC", 
            $user_id,
            $user ? $user['phone'] : ''
        ), ARRAY_A);

        if (!empty($repayments)) {
            foreach ($repayments as &$r) {
                $r['amount'] = floatval($r['amount'] ?? 0);
            }
            unset($r);
        } else {
            $repayments = [];
        }

        $total_limit = 0;
        $total_balance = 0;
        if (!empty($profiles)) {
            foreach ($profiles as $p) {
                $total_limit += floatval($p['credit_limit'] ?? 0);
                $total_balance += floatval($p['current_balance'] ?? 0);
            }
        }
        $available_credit = max(0, $total_limit - $total_balance);

        // Fetch active installment schedules for this customer
        $table_schedules = $wpdb->prefix . 'dube_installment_schedules';
        $schedules_rows = $wpdb->get_results($wpdb->prepare(
            "SELECT s.*, m.store_name, tx.transaction_ref, tx.items_json 
             FROM $table_schedules s 
             LEFT JOIN $table_merchants m ON s.merchant_id = m.id 
             LEFT JOIN $table_tx tx ON s.transaction_id = tx.id 
             WHERE s.customer_id IN (SELECT id FROM $table_cp WHERE user_id = %d OR phone = %s) 
             ORDER BY s.due_date ASC",
            $user_id,
            $user ? $user['phone'] : ''
        ), ARRAY_A);

        $active_schedules = [];
        if (!empty($schedules_rows)) {
            $grouped = [];
            foreach ($schedules_rows as $row) {
                $group_key = !empty($row['transaction_id']) ? 'tx_' . $row['transaction_id'] : 'merchant_' . $row['merchant_id'];
                if (!isset($grouped[$group_key])) {
                    $grouped[$group_key] = [
                        'id' => $group_key,
                        'transaction_id' => $row['transaction_id'] ? intval($row['transaction_id']) : null,
                        'transaction_ref' => $row['transaction_ref'] ?? null,
                        'merchant_id' => intval($row['merchant_id']),
                        'customer_id' => intval($row['customer_id']),
                        'store_name' => $row['store_name'] ?? 'Merchant Store',
                        'installments' => []
                    ];
                }
                $grouped[$group_key]['installments'][] = [
                    'id' => intval($row['id']),
                    'installmentNo' => intval($row['installment_number']),
                    'dueDate' => $row['due_date'],
                    'amount' => floatval($row['amount']),
                    'paidAmount' => floatval($row['paid_amount']),
                    'status' => $row['status']
                ];
            }
            $active_schedules = array_values($grouped);
        }

        return new WP_REST_Response([
            'profiles' => $profiles ? $profiles : [],
            'summary' => [
                'totalCreditLimit' => $total_limit,
                'totalBalance' => $total_balance,
                'availableCredit' => $available_credit,
                'activeAccountsCount' => is_array($profiles) ? count($profiles) : 0
            ],
            'transactions' => $transactions,
            'repayments' => $repayments,
            'activeSchedules' => $active_schedules,
            'activeSchedule' => !empty($active_schedules) ? $active_schedules[0] : null
        ], 200);
    }

    // 10. Customer Repay
    public static function customer_repay($request) {
        global $wpdb;
        $user = self::get_authenticated_user($request);
        $user_id = $user ? $user['id'] : 0;
        $params = $request->get_json_params();

        $table_rep = $wpdb->prefix . 'dube_repayments';
        $table_tx  = $wpdb->prefix . 'dube_credit_transactions';
        $table_cp  = $wpdb->prefix . 'dube_customer_profiles';
        $table_m   = $wpdb->prefix . 'dube_merchants';

        $transaction_id = !empty($params['transactionId']) ? intval($params['transactionId']) : null;
        $customer_id    = intval($params['customerId'] ?? 0);
        $merchant_id    = intval($params['merchantId'] ?? 0);
        $amount         = floatval($params['amount'] ?? 0);
        $gateway        = sanitize_text_field($params['paymentGateway'] ?? 'RECEIPT_UPLOAD');
        $ref_code       = sanitize_text_field($params['referenceCode'] ?? '');
        $receipt_url    = sanitize_text_field($params['receiptUrl'] ?? null);
        $installment_no = !empty($params['installmentNo']) ? intval($params['installmentNo']) : null;

        // Auto-resolve merchant_id and customer_id if missing
        if ($transaction_id && (!$merchant_id || !$customer_id)) {
            $tx_row = $wpdb->get_row($wpdb->prepare("SELECT customer_id, merchant_id FROM $table_tx WHERE id = %d", $transaction_id), ARRAY_A);
            if ($tx_row) {
                if (!$customer_id) $customer_id = intval($tx_row['customer_id']);
                if (!$merchant_id) $merchant_id = intval($tx_row['merchant_id']);
            }
        }

        if (!$customer_id && $user_id) {
            $customer_id = intval($wpdb->get_var($wpdb->prepare("SELECT id FROM $table_cp WHERE user_id = %d LIMIT 1", $user_id)));
        }

        if (!$merchant_id && $customer_id) {
            $merchant_id = intval($wpdb->get_var($wpdb->prepare("SELECT merchant_id FROM $table_cp WHERE id = %d", $customer_id)));
        }

        $store_name = 'Merchant Store';
        if ($merchant_id) {
            $store_name = $wpdb->get_var($wpdb->prepare("SELECT store_name FROM $table_m WHERE id = %d", $merchant_id)) ?: 'Merchant Store';
        }

        if ($amount <= 0) {
            return new WP_REST_Response(['error' => 'Valid repayment amount is required.'], 400);
        }

        $rep_ref = 'PAY-' . strtoupper(wp_generate_password(6, false));
        $is_upload = ($gateway === 'RECEIPT_UPLOAD');
        $status = $is_upload ? 'PENDING' : 'COMPLETED';

        $wpdb->insert($table_rep, [
            'repayment_ref'   => $rep_ref,
            'transaction_id'  => $transaction_id,
            'customer_id'     => $customer_id,
            'merchant_id'     => $merchant_id,
            'amount'          => $amount,
            'payment_gateway' => $gateway,
            'reference_code'  => $ref_code,
            'receipt_url'     => $receipt_url,
            'status'          => $status,
            'created_at'      => current_time('mysql')
        ]);

        $repayment_id = $wpdb->insert_id;

        // If instant digital payment (Telebirr, CBE Birr, Chapa) - complete settlement immediately
        if (!$is_upload) {
            // Deduct customer current balance
            if ($customer_id) {
                $wpdb->query($wpdb->prepare("UPDATE $table_cp SET current_balance = GREATEST(0, current_balance - %f) WHERE id = %d", $amount, $customer_id));
            }
            // Settle transaction
            if ($transaction_id) {
                $paid_sum = floatval($wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount), 0) FROM $table_rep WHERE transaction_id = %d AND status = 'COMPLETED'", $transaction_id)));
                $tx_total = floatval($wpdb->get_var($wpdb->prepare("SELECT total_amount FROM $table_tx WHERE id = %d", $transaction_id)));
                if ($paid_sum >= $tx_total) {
                    $wpdb->update($table_tx, ['status' => 'SETTLED'], ['id' => $transaction_id]);
                } else if ($paid_sum > 0) {
                    $wpdb->update($table_tx, ['status' => 'PARTIALLY_PAID'], ['id' => $transaction_id]);
                }
            }
        }

        // If installment specified, mark that installment
        if ($installment_no && $transaction_id) {
            $table_schedules = $wpdb->prefix . 'dube_installment_schedules';
            if ($wpdb->get_var("SHOW TABLES LIKE '$table_schedules'")) {
                $wpdb->update($table_schedules, [
                    'status' => ($status === 'COMPLETED') ? 'PAID' : 'PENDING_APPROVAL',
                    'paid_amount' => $amount
                ], [
                    'transaction_id' => $transaction_id,
                    'installment_number' => $installment_no
                ]);
            }
        }

        return new WP_REST_Response([
            'message' => $is_upload 
                ? 'Payment receipt submitted successfully and is awaiting merchant verification' 
                : 'Payment settlement completed successfully',
            'repaymentRef' => $rep_ref,
            'receipt' => [
                'id'              => $repayment_id,
                'repaymentRef'    => $rep_ref,
                'repayment_ref'   => $rep_ref,
                'refCode'         => $ref_code,
                'referenceCode'   => $ref_code,
                'amount'          => $amount,
                'gateway'         => $gateway,
                'payment_gateway' => $gateway,
                'status'          => $status,
                'receiptUrl'      => $receipt_url,
                'receipt_url'     => $receipt_url,
                'customerId'      => $customer_id,
                'merchantId'      => $merchant_id,
                'transactionId'   => $transaction_id,
                'storeName'       => $store_name,
                'store_name'      => $store_name,
                'created_at'      => current_time('mysql')
            ]
        ], 201);
    }

    // 11. Customer Schedule Endpoints
    public static function handle_customer_schedule($request) {
        global $wpdb;
        $table_schedules = $wpdb->prefix . 'dube_installment_schedules';

        if ($request->get_method() === 'POST') {
            $params = $request->get_json_params();
            $total_amount = floatval($params['totalAmount'] ?? 0);
            $frequency = strtoupper(sanitize_text_field($params['frequency'] ?? 'WEEKLY'));
            $num_installments = max(1, intval($params['numInstallments'] ?? 2));
            $transaction_id = !empty($params['transactionId']) ? intval($params['transactionId']) : null;
            $deadline_date_str = !empty($params['deadlineDate']) ? sanitize_text_field($params['deadlineDate']) : null;

            // If deadline not explicitly passed but transactionId is, look up that transaction's due_date
            if (!$deadline_date_str && $transaction_id) {
                $table_tx = $wpdb->prefix . 'dube_credit_transactions';
                $raw = $wpdb->get_var($wpdb->prepare("SELECT due_date FROM $table_tx WHERE id = %d", $transaction_id));
                if ($raw) {
                    $deadline_date_str = substr($raw, 0, 10); // ensure YYYY-MM-DD
                }
            }

            if ($total_amount <= 0) {
                return new WP_REST_Response(['error' => 'Valid debt amount is required to calculate schedule.'], 400);
            }

            // --- Exact port of Node.js calculateFlexibleInstallments() ---
            $today = new DateTime('today'); // midnight local time

            // Parse deadline
            $deadline_dt = null;
            if ($deadline_date_str) {
                $deadline_dt = DateTime::createFromFormat('Y-m-d', $deadline_date_str);
                if ($deadline_dt) $deadline_dt->setTime(0, 0, 0);
            }

            // Fallback: end of current month
            if (!$deadline_dt || $deadline_dt === false) {
                $deadline_dt = new DateTime('last day of this month');
                $deadline_dt->setTime(0, 0, 0);
            }

            // Clamp to today if in the past
            if ($deadline_dt < $today) {
                $deadline_dt = clone $today;
            }

            $deadline_day   = (int)$deadline_dt->format('j');
            $deadline_month = (int)$deadline_dt->format('n') - 1; // 0-indexed
            $deadline_year  = (int)$deadline_dt->format('Y');

            // Build raw dates going back from deadline
            $raw_dates = [];
            for ($i = $num_installments - 1; $i >= 0; $i--) {
                $d = clone $deadline_dt;
                if ($frequency === 'WEEKLY') {
                    // Weekly: go back i*7 days from deadline
                    $d->modify("-{$i} week");
                } else {
                    // Monthly: go back i months, pin to same day-of-month
                    $target_month = $deadline_month - $i;
                    $target_year  = $deadline_year + intval(floor($target_month / 12));
                    $normalized_month = (($target_month % 12) + 12) % 12;
                    $last_day = (int)(new DateTime("{$target_year}-" . sprintf('%02d', $normalized_month + 1) . "-01"))->format('t');
                    $target_day = min($deadline_day, $last_day);
                    $d = new DateTime(sprintf('%04d-%02d-%02d', $target_year, $normalized_month + 1, $target_day));
                }
                $raw_dates[] = $d;
            }

            // Filter out strictly past dates
            $valid_dates = array_filter($raw_dates, function($d) use ($today) {
                return $d >= $today;
            });
            $valid_dates = array_values($valid_dates);

            if (empty($valid_dates)) {
                $valid_dates = [clone $deadline_dt];
            }

            $actual_num_inst = count($valid_dates);
            $per_installment = $total_amount / $actual_num_inst;
            $installments = [];

            foreach ($valid_dates as $idx => $due_dt) {
                $installments[] = [
                    'installmentNo' => $idx + 1,
                    'dueDate'       => $due_dt->format('Y-m-d'),
                    'amount'        => floatval(number_format($per_installment, 2, '.', '')),
                    'status'        => 'SCHEDULED',
                    'isDeadline'    => ($idx === $actual_num_inst - 1)
                ];
            }

            $deadline_str = $deadline_dt->format('Y-m-d');

            return new WP_REST_Response([
                'totalAmount'     => $total_amount,
                'frequency'       => $frequency,
                'numInstallments' => $actual_num_inst,
                'deadlineDate'    => $deadline_str,
                'installments'    => $installments
            ], 200);
        }

        $schedules = $wpdb->get_results("SELECT * FROM $table_schedules ORDER BY due_date ASC", ARRAY_A);
        return new WP_REST_Response(['schedules' => $schedules], 200);
    }

    public static function apply_customer_schedule($request) {
        global $wpdb;
        $user = self::get_authenticated_user($request);
        $user_id = $user ? $user['id'] : 0;

        $params = $request->get_json_params();
        $table_schedules = $wpdb->prefix . 'dube_installment_schedules';
        $table_cp = $wpdb->prefix . 'dube_customer_profiles';

        $customer_id = intval($params['customerId'] ?? 0);
        $merchant_id = intval($params['merchantId'] ?? 0);
        $transaction_id = !empty($params['transactionId']) ? intval($params['transactionId']) : null;
        $installments = $params['installments'] ?? [];

        if (!$customer_id && $user_id) {
            $customer_id = intval($wpdb->get_var($wpdb->prepare("SELECT id FROM $table_cp WHERE user_id = %d LIMIT 1", $user_id)));
        }

        if (!$merchant_id && $transaction_id) {
            $table_tx = $wpdb->prefix . 'dube_credit_transactions';
            $merchant_id = intval($wpdb->get_var($wpdb->prepare("SELECT merchant_id FROM $table_tx WHERE id = %d", $transaction_id)));
        }

        // Delete previous pending installments for this transaction or merchant to avoid duplicate schedule entries
        if ($transaction_id) {
            $wpdb->query($wpdb->prepare(
                "DELETE FROM $table_schedules WHERE transaction_id = %d AND status = 'PENDING'", 
                $transaction_id
            ));
        } elseif ($customer_id && $merchant_id) {
            $wpdb->query($wpdb->prepare(
                "DELETE FROM $table_schedules WHERE customer_id = %d AND merchant_id = %d AND (transaction_id IS NULL OR transaction_id = 0) AND status = 'PENDING'", 
                $customer_id, 
                $merchant_id
            ));
        }

        if (!empty($installments) && is_array($installments)) {
            foreach ($installments as $inst) {
                $wpdb->insert($table_schedules, [
                    'transaction_id' => $transaction_id,
                    'customer_id' => $customer_id,
                    'merchant_id' => $merchant_id,
                    'installment_number' => intval($inst['installmentNo'] ?? 1),
                    'due_date' => sanitize_text_field($inst['dueDate'] ?? date('Y-m-d')),
                    'amount' => floatval($inst['amount'] ?? 0),
                    'paid_amount' => 0.00,
                    'status' => 'PENDING'
                ]);
            }

            // Synchronize the transaction's due_date to match the final installment date
            if ($transaction_id) {
                $last_inst = end($installments);
                if (!empty($last_inst['dueDate'])) {
                    $table_tx = $wpdb->prefix . 'dube_credit_transactions';
                    $wpdb->update($table_tx, ['due_date' => sanitize_text_field($last_inst['dueDate'])], ['id' => $transaction_id]);
                }
            }
        }

        return new WP_REST_Response([
            'message' => 'Flexible Repayment Schedule applied successfully',
            'success' => true
        ], 200);
    }

    // 12. Admin Dashboard & Gateways
    public static function get_admin_dashboard($request) {
        global $wpdb;
        $table_merchants = $wpdb->prefix . 'dube_merchants';
        $table_users = $wpdb->prefix . 'dube_users';
        $table_tx = $wpdb->prefix . 'dube_credit_transactions';
        $table_rep = $wpdb->prefix . 'dube_repayments';
        $table_cp = $wpdb->prefix . 'dube_customer_profiles';

        $merchants = $wpdb->get_results("SELECT m.*, u.full_name as owner_name, u.phone as owner_phone FROM $table_merchants m JOIN $table_users u ON m.user_id = u.id", ARRAY_A);
        
        $total_dube = $wpdb->get_var("SELECT COALESCE(SUM(total_amount), 0) FROM $table_tx");
        $total_rep = $wpdb->get_var("SELECT COALESCE(SUM(amount), 0) FROM $table_rep WHERE status = 'COMPLETED'");
        $total_merchants_count = $wpdb->get_var("SELECT COUNT(*) FROM $table_merchants");
        $pending_kyc_count = $wpdb->get_var("SELECT COUNT(*) FROM $table_merchants WHERE kyc_status = 'PENDING'");
        $active_merchants_count = $wpdb->get_var("SELECT COUNT(*) FROM $table_merchants WHERE kyc_status = 'VERIFIED'");
        $active_cust_count = $wpdb->get_var("SELECT COUNT(*) FROM $table_cp WHERE status = 'ACTIVE'");
        
        $transactions = $wpdb->get_results("SELECT * FROM $table_tx ORDER BY id DESC LIMIT 50", ARRAY_A);

        return new WP_REST_Response([
            'merchants' => $merchants ?: [],
            'metrics' => [
                'totalMerchants' => intval($total_merchants_count ?: (is_array($merchants) ? count($merchants) : 0)),
                'activeMerchants' => intval($active_merchants_count),
                'pendingKycCount' => intval($pending_kyc_count),
                'totalDubeIssued' => floatval($total_dube),
                'totalRepayments' => floatval($total_rep),
                'activeCustomers' => intval($active_cust_count)
            ],
            'transactions' => $transactions ?: []
        ], 200);
    }

    public static function handle_webhook_test($request) {
        return new WP_REST_Response([
            'message' => 'Simulated gateway webhook processed successfully',
            'status' => 'SUCCESS'
        ], 200);
    }

    public static function get_admin_gateways($request) {
        return new WP_REST_Response([
            'gateways' => [
                ['name' => 'TELEBIRR', 'status' => 'ONLINE', 'successRate' => '99.4%'],
                ['name' => 'CBE_BIRR', 'status' => 'ONLINE', 'successRate' => '98.8%'],
                ['name' => 'CHAPA', 'status' => 'ONLINE', 'successRate' => '99.9%'],
                ['name' => 'AFRICAS_TALKING_SMS', 'status' => 'ONLINE', 'successRate' => '99.1%']
            ]
        ], 200);
    }

    public static function get_admin_audit_logs($request) {
        global $wpdb;
        $table_audit = $wpdb->prefix . 'dube_audit_logs';
        $logs = $wpdb->get_results("SELECT * FROM $table_audit ORDER BY id DESC LIMIT 50", ARRAY_A);
        return new WP_REST_Response(['logs' => $logs], 200);
    }

    public static function update_merchant_kyc($request) {
        global $wpdb;
        $merchant_id = intval($request['id']);
        $params = $request->get_json_params();
        $status = sanitize_text_field($params['status'] ?? 'VERIFIED');

        $table_merchants = $wpdb->prefix . 'dube_merchants';
        $wpdb->update($table_merchants, ['kyc_status' => $status, 'verified_at' => current_time('mysql')], ['id' => $merchant_id]);

        return new WP_REST_Response(['message' => "Merchant KYC status updated to $status"], 200);
    }

    public static function forgot_password($request) {
        return new WP_REST_Response(['message' => 'Reset PIN sent via SMS'], 200);
    }

    public static function reset_password($request) {
        return new WP_REST_Response(['message' => 'Password reset successful'], 200);
    }
}
